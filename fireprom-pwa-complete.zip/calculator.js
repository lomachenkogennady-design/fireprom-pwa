/**
 * FireProM Portal — Door Calculator
 * Расчёт стоимости противопожарных дверей
 */

const Calculator = {
    // Цены на типы дверей (₽/м²)
    doorPrices: {
        1: 44000, 2: 42000, 3: 40000, 4: 32000, 5: 35000,
        6: 37000, 7: 44000, 8: 44000, 9: 40000, 10: 35000, 11: 42000
    },

    // Опции
    options: {
        antipanic: { multiplier: 1.15, label: 'Антипаника' },
        electromagnet: { price: 8500, label: 'Электромагнитный замок' },
        canopy: { price: 3200, label: 'Козырёк С8' },
        psul: { price: 0, label: 'Монтаж с ПСУЛ' } // цена из прайса
    },

    // Монтажные работы
    installPrices: {
        measure: 1200,
        delivery: 6600,
        lift: { normal: 480, high: 600 },
        dismantle: { simple: 480, complex: 1440 },
        install: { simple: 6000, complex: 13200 }
    },

    calculate(data) {
        const width = parseInt(data.width) || 980;
        const height = parseInt(data.height) || 2000;
        const quantity = parseInt(data.quantity) || 1;
        const type = data.type || '1';
        const options = data.options || {};

        // Площадь одной двери в м²
        const area = (width * height) / 1000000;
        const pricePerM2 = this.doorPrices[type] || 44000;

        // Стоимость дверей
        let doorCost = area * pricePerM2 * quantity;

        // Дополнительные опции
        let optionsCost = 0;
        const selectedOptions = [];

        if (options.antipanic) {
            doorCost *= 1.15;
            selectedOptions.push('Антипаника (+15%)');
        }
        if (options.electromagnet) {
            optionsCost += 8500 * quantity;
            selectedOptions.push('Электромагнитный замок');
        }
        if (options.canopy) {
            optionsCost += 3200 * quantity;
            selectedOptions.push('Козырёк С8');
        }

        // Монтаж (если выбран)
        let installCost = 0;
        if (options.psul) {
            // Упрощённый расчёт — простой монтаж
            installCost = this.installPrices.install.simple * quantity;
            selectedOptions.push('Монтаж с ПСУЛ');
        }

        // Доставка (1 рейс)
        const deliveryCost = this.installPrices.delivery;

        // Итого без НДС
        const subtotal = doorCost + optionsCost + installCost + deliveryCost;

        // НДС 22%
        const vat = subtotal * 0.22;
        const total = subtotal + vat;

        return {
            area: area.toFixed(3),
            areaTotal: (area * quantity).toFixed(3),
            doorCost: Math.round(doorCost),
            optionsCost: Math.round(optionsCost),
            installCost: Math.round(installCost),
            deliveryCost: Math.round(deliveryCost),
            subtotal: Math.round(subtotal),
            vat: Math.round(vat),
            total: Math.round(total),
            selectedOptions,
            quantity
        };
    },

    formatPrice(price) {
        return new Intl.NumberFormat('ru-RU').format(price) + ' ₽';
    }
};

// DOM integration
document.addEventListener('DOMContentLoaded', () => {
    const calcBtn = document.getElementById('calc-btn');
    const saveBtn = document.getElementById('calc-save');
    const shareBtn = document.getElementById('calc-share');

    if (calcBtn) {
        calcBtn.addEventListener('click', () => {
            const data = {
                type: document.getElementById('calc-type')?.value || '1',
                width: document.getElementById('calc-width')?.value || 980,
                height: document.getElementById('calc-height')?.value || 2000,
                quantity: document.getElementById('calc-quantity')?.value || 1,
                options: {
                    antipanic: document.getElementById('calc-antipanic')?.checked || false,
                    electromagnet: document.getElementById('calc-electromagnet')?.checked || false,
                    canopy: document.getElementById('calc-canopy')?.checked || false,
                    psul: document.getElementById('calc-psul')?.checked || false
                }
            };

            const result = Calculator.calculate(data);

            document.getElementById('res-area').textContent = 
                `${result.areaTotal} м² (${result.quantity} шт. × ${result.area} м²)`;
            document.getElementById('res-door-cost').textContent = Calculator.formatPrice(result.doorCost);
            document.getElementById('res-options').textContent = Calculator.formatPrice(result.optionsCost);
            document.getElementById('res-install').textContent = Calculator.formatPrice(result.installCost);
            document.getElementById('res-total').textContent = Calculator.formatPrice(result.total);

            // Show options row if there are options
            const optionsRow = document.getElementById('res-options-row');
            if (optionsRow) optionsRow.style.display = result.optionsCost > 0 ? 'flex' : 'none';

            const installRow = document.getElementById('res-install-row');
            if (installRow) installRow.style.display = result.installCost > 0 ? 'flex' : 'none';

            // Show result card
            document.getElementById('calc-result').classList.add('show');
        });
    }

    if (saveBtn) {
        saveBtn.addEventListener('click', async () => {
            const data = {
                type: document.getElementById('calc-type')?.value,
                width: document.getElementById('calc-width')?.value,
                height: document.getElementById('calc-height')?.value,
                quantity: document.getElementById('calc-quantity')?.value,
                options: {
                    antipanic: document.getElementById('calc-antipanic')?.checked,
                    electromagnet: document.getElementById('calc-electromagnet')?.checked,
                    canopy: document.getElementById('calc-canopy')?.checked,
                    psul: document.getElementById('calc-psul')?.checked
                },
                timestamp: new Date().toISOString()
            };

            try {
                await db.put('calculations', data);
                showToast('Расчёт сохранён', 'success');
            } catch (e) {
                showToast('Ошибка сохранения', 'error');
            }
        });
    }

    if (shareBtn) {
        shareBtn.addEventListener('click', async () => {
            const totalText = document.getElementById('res-total')?.textContent || '';
            const shareData = {
                title: 'FireProM — Расчёт дверей',
                text: `Стоимость противопожарных дверей: ${totalText}`,
                url: window.location.href
            };

            if (navigator.share) {
                try {
                    await navigator.share(shareData);
                } catch (e) {
                    // User cancelled
                }
            } else {
                // Fallback — copy to clipboard
                const text = `${shareData.title}\n${shareData.text}`;
                navigator.clipboard.writeText(text).then(() => {
                    showToast('Скопировано в буфер обмена', 'success');
                });
            }
        });
    }
});
