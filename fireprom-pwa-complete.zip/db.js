/**
 * FireProM Portal — IndexedDB Layer
 * Локальное хранилище данных с seed-данными
 */

const DB_NAME = 'FireProM_DB';
const DB_VERSION = 1;

const doorPrices = {
    1: { name: 'ТИП 1 — Стандартная', price: 44000 },
    2: { name: 'ТИП 2 — Усиленная', price: 42000 },
    3: { name: 'ТИП 3 — Эконом', price: 40000 },
    4: { name: 'ТИП 4 — Базовая', price: 32000 },
    5: { name: 'ТИП 5 — Компакт', price: 35000 },
    6: { name: 'ТИП 6 — Премиум', price: 37000 },
    7: { name: 'ТИП 7 — Премиум+', price: 44000 },
    8: { name: 'ТИП 8 — Максимум', price: 44000 },
    9: { name: 'ТИП 9 — Стандарт+', price: 40000 },
    10: { name: 'ТИП 10 — Компакт+', price: 35000 },
    11: { name: 'ТИП 11 — Усиленная+', price: 42000 }
};

const installPrices = [
    { name: 'Замер', unit: 'шт.', price: 1200 },
    { name: 'Доставка', unit: 'рейс', price: 6600 },
    { name: 'Подъём (1 этаж)', unit: 'этаж', price: 480 },
    { name: 'Подъём (свыше 5 этажей)', unit: 'этаж', price: 600 },
    { name: 'Демонтаж (простой)', unit: 'шт.', price: 480 },
    { name: 'Демонтаж (сложный)', unit: 'шт.', price: 1440 },
    { name: 'Монтаж с ПСУЛ (простой)', unit: 'шт.', price: 6000 },
    { name: 'Монтаж с ПСУЛ (сложный)', unit: 'шт.', price: 13200 },
    { name: 'Откосы ГКЛ', unit: 'компл.', price: 3849 },
    { name: 'Откосы штукатурные', unit: 'компл.', price: 4168 },
    { name: 'Металлопортал', unit: 'компл.', price: 19520 },
    { name: 'Документация', unit: 'компл.', price: 45000 }
];

const seedClients = [
    {
        id: 'client-1',
        name: 'ООО «НПО «ГИДРОАТОМ»',
        inn: '7841064608',
        kpp: '783801001',
        ogrn: '1177847269786',
        director: 'Жирноклеева Ирина Владимировна',
        address: '190031, СПб, ул. Ефимова, д. 4а лит. А, пом. 24-н, офис 523',
        email: 'gidroatom-npo@yandex.ru',
        phone: '+7 (911) 824-49-15',
        bank: 'Альфа-Банк',
        account: '40702810632200001979',
        bik: '044030786',
        notes: 'СРО строительное и проектирование 1 уровень'
    },
    {
        id: 'client-2',
        name: 'ООО «ЖКС №2 Калининского района»',
        inn: '',
        address: 'СПб, Калининский район',
        email: '',
        phone: '',
        notes: 'Заказчик по тендеру ЗПЭ № 0865200000126000107'
    },
    {
        id: 'client-3',
        name: 'ООО «СТД «Петрович»',
        inn: '',
        address: 'СПб, пр. Энгельса, 157 лит. А',
        email: '',
        phone: '',
        notes: 'КП от 25.06.2026 — 2 противопожарные двери'
    }
];

const seedOrders = [
    {
        id: 'order-1',
        clientId: 'client-3',
        clientName: 'ООО «СТД «Петрович»',
        address: 'пр. Энгельса, 157 лит. А',
        type: '1',
        quantity: 1,
        width: 980,
        height: 2000,
        status: 'production',
        note: 'ДПМ01 980×2000, одностворчатая, RAL 9003, антипаника, козырёк С8',
        createdAt: '2026-06-25T10:00:00Z',
        updatedAt: '2026-06-26T14:30:00Z'
    },
    {
        id: 'order-2',
        clientId: 'client-3',
        clientName: 'ООО «СТД «Петрович»',
        address: 'пр. Энгельса, 157 лит. А',
        type: '7',
        quantity: 1,
        width: 1350,
        height: 2120,
        status: 'processing',
        note: 'ДПМ02 1350×2120, двустворчатая, RAL 9003/7004, антипаника',
        createdAt: '2026-06-25T10:00:00Z',
        updatedAt: '2026-06-25T10:00:00Z'
    },
    {
        id: 'order-3',
        clientId: 'client-2',
        clientName: 'ООО «ЖКС №2 Калининского района»',
        address: 'Академика Байкова 13к2',
        type: '1',
        quantity: 5,
        width: 980,
        height: 2000,
        status: 'new',
        note: 'Тендер ЗПЭ № 0865200000126000107, 39 дверей',
        createdAt: '2026-06-28T08:00:00Z',
        updatedAt: '2026-06-28T08:00:00Z'
    }
];

class FireProMDB {
    constructor() {
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                if (!db.objectStoreNames.contains('clients')) {
                    db.createObjectStore('clients', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('orders')) {
                    const orderStore = db.createObjectStore('orders', { keyPath: 'id' });
                    orderStore.createIndex('status', 'status', { unique: false });
                    orderStore.createIndex('clientId', 'clientId', { unique: false });
                }
                if (!db.objectStoreNames.contains('calculations')) {
                    db.createObjectStore('calculations', { keyPath: 'id', autoIncrement: true });
                }
                if (!db.objectStoreNames.contains('settings')) {
                    db.createObjectStore('settings', { keyPath: 'key' });
                }
            };
        });
    }

    async seedData() {
        const settings = await this.getSetting('seeded');
        if (settings?.value) return;

        // Seed clients
        for (const client of seedClients) {
            await this.put('clients', client);
        }
        // Seed orders
        for (const order of seedOrders) {
            await this.put('orders', order);
        }
        await this.setSetting('seeded', true);
        await this.setSetting('lastSync', new Date().toISOString());
    }

    async put(storeName, data) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.put(data);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async get(storeName, id) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const request = store.get(id);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getAll(storeName) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const request = store.getAll();
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async delete(storeName, id) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.delete(id);
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    async getByIndex(storeName, indexName, value) {
        return new Promise((resolve, reject) => {
            const tx = this.db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const index = store.index(indexName);
            const request = index.getAll(value);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async setSetting(key, value) {
        await this.put('settings', { key, value });
    }

    async getSetting(key) {
        return await this.get('settings', key);
    }
}

// Global instance
const db = new FireProMDB();
