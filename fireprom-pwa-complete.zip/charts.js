/**
 * FireProM Portal — Charts Module
 * Графики и визуализация данных
 */

const Charts = {
    instances: {},

    initRevenueChart() {
        const ctx = document.getElementById('revenue-chart');
        if (!ctx) return;

        // Демо-данные выручки по месяцам
        const months = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн'];
        const revenue = [1250000, 1580000, 1420000, 1890000, 2100000, 1950000];

        this.instances.revenue = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: months,
                datasets: [{
                    label: 'Выручка (₽)',
                    data: revenue,
                    backgroundColor: 'rgba(230, 57, 70, 0.7)',
                    borderColor: '#e63946',
                    borderWidth: 1,
                    borderRadius: 6,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#1a1a2e',
                        titleColor: '#f1f1f1',
                        bodyColor: '#f1f1f1',
                        borderColor: '#2a2a45',
                        borderWidth: 1,
                        callbacks: {
                            label: (context) => {
                                return new Intl.NumberFormat('ru-RU', {
                                    style: 'currency',
                                    currency: 'RUB',
                                    maximumFractionDigits: 0
                                }).format(context.raw);
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: { display: false, color: '#2a2a45' },
                        ticks: { color: '#a0a0b8', font: { size: 11 } }
                    },
                    y: {
                        grid: { color: 'rgba(42, 42, 69, 0.5)' },
                        ticks: {
                            color: '#a0a0b8',
                            font: { size: 11 },
                            callback: (value) => {
                                return (value / 1000000).toFixed(1) + ' млн';
                            }
                        }
                    }
                }
            }
        });
    },

    initOrdersChart() {
        const ctx = document.getElementById('orders-chart');
        if (!ctx) return;

        // Демо-данные статусов заявок
        const data = {
            labels: ['Новые', 'В обработке', 'В производстве', 'Готовы', 'Доставлены'],
            datasets: [{
                data: [5, 8, 12, 4, 18],
                backgroundColor: [
                    '#3498db',
                    '#f39c12',
                    '#e63946',
                    '#2ecc71',
                    '#27ae60'
                ],
                borderWidth: 0,
                hoverOffset: 8
            }]
        };

        this.instances.orders = new Chart(ctx, {
            type: 'doughnut',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '65%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#a0a0b8',
                            font: { size: 11 },
                            padding: 16,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: '#1a1a2e',
                        titleColor: '#f1f1f1',
                        bodyColor: '#f1f1f1',
                        borderColor: '#2a2a45',
                        borderWidth: 1
                    }
                }
            }
        });
    },

    updateKPIs(orders, clients) {
        // Выручка (демо)
        const revenueEl = document.getElementById('kpi-revenue');
        if (revenueEl) {
            revenueEl.textContent = new Intl.NumberFormat('ru-RU').format(1950000) + ' ₽';
        }

        // Активные заявки
        const activeOrders = orders?.filter(o => 
            ['new', 'processing', 'production'].includes(o.status)
        )?.length || 0;
        const ordersEl = document.getElementById('kpi-orders');
        if (ordersEl) ordersEl.textContent = activeOrders;

        // Клиенты
        const clientsEl = document.getElementById('kpi-clients');
        if (clientsEl) clientsEl.textContent = clients?.length || 0;

        // Двери в производстве
        const prodOrders = orders?.filter(o => o.status === 'production')?.length || 0;
        const doorsEl = document.getElementById('kpi-doors');
        if (doorsEl) doorsEl.textContent = prodOrders;
    },

    destroy() {
        Object.values(this.instances).forEach(chart => chart.destroy());
        this.instances = {};
    }
};
