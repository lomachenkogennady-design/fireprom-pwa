/**
 * FireProM Portal — Service Worker
 * Cache First стратегия для офлайн-работы
 */

const CACHE_NAME = 'fireprom-pwa-v1';
const STATIC_ASSETS = [
    '/fireprom-pwa/',
    '/fireprom-pwa/index.html',
    '/fireprom-pwa/app.css',
    '/fireprom-pwa/db.js',
    '/fireprom-pwa/calculator.js',
    '/fireprom-pwa/charts.js',
    '/fireprom-pwa/app.js',
    '/fireprom-pwa/manifest.json'
];

// CDN ресурсы для кэширования
const CDN_ASSETS = [
    'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js'
];

// Install — кэшируем статику
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('[SW] Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => self.skipWaiting())
            .catch(err => console.error('[SW] Cache failed:', err))
    );
});

// Activate — чистим старые кэши
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames
                    .filter(name => name !== CACHE_NAME)
                    .map(name => {
                        console.log('[SW] Deleting old cache:', name);
                        return caches.delete(name);
                    })
            );
        }).then(() => self.clients.claim())
    );
});

// Fetch — Cache First стратегия
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);

    // Пропускаем не-GET запросы
    if (request.method !== 'GET') return;

    // Стратегия для статики
    if (STATIC_ASSETS.includes(url.pathname) || CDN_ASSETS.includes(request.url)) {
        event.respondWith(
            caches.match(request).then(cached => {
                if (cached) {
                    // Фоновое обновление
                    fetch(request)
                        .then(response => {
                            if (response.ok) {
                                caches.open(CACHE_NAME).then(cache => {
                                    cache.put(request, response.clone());
                                });
                            }
                        })
                        .catch(() => {});
                    return cached;
                }
                return fetch(request).then(response => {
                    if (response.ok) {
                        const clone = response.clone();
                        caches.open(CACHE_NAME).then(cache => {
                            cache.put(request, clone);
                        });
                    }
                    return response;
                });
            })
        );
        return;
    }

    // Для остальных запросов — Network First с fallback
    event.respondWith(
        fetch(request)
            .then(response => {
                if (response.ok && request.url.startsWith(self.location.origin)) {
                    const clone = response.clone();
                    caches.open(CACHE_NAME).then(cache => {
                        cache.put(request, clone);
                    });
                }
                return response;
            })
            .catch(() => {
                return caches.match(request).then(cached => {
                    if (cached) return cached;
                    // Fallback для навигации
                    if (request.mode === 'navigate') {
                        return caches.match('/fireprom-pwa/index.html');
                    }
                    return new Response('Офлайн-режим: данные недоступны', {
                        status: 503,
                        headers: { 'Content-Type': 'text/plain' }
                    });
                });
            })
    );
});

// Background Sync
self.addEventListener('sync', (event) => {
    if (event.tag === 'sync-orders') {
        event.waitUntil(syncOrders());
    }
});

async function syncOrders() {
    // Здесь будет логика синхронизации с сервером
    console.log('[SW] Background sync: orders');
    const clients = await self.clients.matchAll();
    clients.forEach(client => {
        client.postMessage({ type: 'SYNC_COMPLETE' });
    });
}

// Push notifications
self.addEventListener('push', (event) => {
    const data = event.data?.json() || {};
    const options = {
        body: data.body || 'Новое уведомление',
        icon: 'data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 192 192'%3E%3Crect width='192' height='192' rx='40' fill='%23e63946'/%3E%3Ctext x='96' y='130' font-size='110' text-anchor='middle' fill='white' font-family='Arial' font-weight='bold'%3EF%3C/text%3E%3C/svg%3E',
        badge: 'data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 96 96'%3E%3Crect width='96' height='96' rx='20' fill='%23e63946'/%3E%3Ctext x='48' y='65' font-size='50' text-anchor='middle' fill='white' font-family='Arial' font-weight='bold'%3EF%3C/text%3E%3C/svg%3E',
        tag: data.tag || 'fireprom-notification',
        requireInteraction: false,
        data: data
    };

    event.waitUntil(
        self.registration.showNotification(data.title || 'FireProM', options)
    );
});

// Notification click
self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    event.waitUntil(
        clients.openWindow('/fireprom-pwa/')
    );
});

// Message from client
self.addEventListener('message', (event) => {
    if (event.data === 'SKIP_WAITING') {
        self.skipWaiting();
    }
});
