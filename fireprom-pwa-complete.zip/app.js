/**
 * FireProM Portal — Main Application
 * SPA Router, UI Logic, Data Binding
 */

// ============================================
// TOAST NOTIFICATIONS
// ============================================
function showToast(message, type = 'info', duration = 3000) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    const icons = {
        success: '✓',
        error: '✕',
        warning: '⚠',
        info: 'ℹ'
    };

    toast.innerHTML = `<span>${icons[type] || 'ℹ'}</span><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(100%)';
        setTimeout(() => toast.remove(), 300);
    }, duration);
}

// ============================================
// APP STATE
// ============================================
const App = {
    currentPage: 'dashboard',
    sidebarOpen: false,
    installPrompt: null,
    orders: [],
    clients: [],

    async init() {
        // Initialize DB
        try {
            await db.init();
            await db.seedData();
            console.log('Database initialized');
        } catch (e) {
            console.error('DB init failed:', e);
            showToast('Ошибка инициализации базы данных', 'error');
        }

        // Load data
        await this.loadData();

        // Setup UI
        this.setupNavigation();
        this.setupSidebar();
        this.setupInstallPrompt();
        this.setupOfflineDetection();
        this.setupSync();
        this.setupModals();

        // Initial render
        this.renderPage('dashboard');

        // Hide splash
        setTimeout(() => {
            document.getElementById('splash-screen')?.classList.add('hidden');
            document.getElementById('app')?.classList.remove('hidden');
        }, 1500);
    },

    async loadData() {
        try {
            this.orders = await db.getAll('orders') || [];
            this.clients = await db.getAll('clients') || [];
            this.updateUI();
        } catch (e) {
            console.error('Load data failed:', e);
        }
    },

    updateUI() {
        this.renderOrders();
        this.renderClients();
        this.renderPriceList();
        this.updateBadges();

        // Update KPIs and charts if on dashboard
        if (this.currentPage === 'dashboard') {
            Charts.updateKPIs(this.orders, this.clients);
            Charts.initRevenueChart();
            Charts.initOrdersChart();
            this.renderRecentOrders();
        }
    },

    // ============================================
    // NAVIGATION
    // ============================================
    setupNavigation() {
        // Hash-based routing
        window.addEventListener('hashchange', () => this.handleRoute());

        // Nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = link.dataset.page;
                if (page) {
                    window.location.hash = page;
                    this.closeSidebar();
                }
            });
        });

        // Initial route
        this.handleRoute();
    },

    handleRoute() {
        const hash = window.location.hash.replace('#', '') || 'dashboard';
        this.renderPage(hash);
    },

    renderPage(page) {
        this.currentPage = page;

        // Update nav active state
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.toggle('active', link.dataset.page === page);
        });

        // Show/hide pages
        document.querySelectorAll('.page').forEach(p => {
            p.classList.toggle('active', p.id === `page-${page}`);
        });

        // Page-specific init
        if (page === 'dashboard') {
            Charts.destroy();
            this.updateUI();
        } else if (page === 'orders') {
            this.renderOrders();
        } else if (page === 'clients') {
            this.renderClients();
        } else if (page === 'pricelist') {
            this.renderPriceList();
        }

        window.scrollTo(0, 0);
    },

    // ============================================
    // SIDEBAR
    // ============================================
    setupSidebar() {
        const toggle = document.getElementById('menu-toggle');
        const overlay = document.getElementById('sidebar-overlay');

        toggle?.addEventListener('click', () => this.toggleSidebar());
        overlay?.addEventListener('click', () => this.closeSidebar());
    },

    toggleSidebar() {
        this.sidebarOpen = !this.sidebarOpen;
        document.getElementById('sidebar')?.classList.toggle('open', this.sidebarOpen);
        document.getElementById('sidebar-overlay')?.classList.toggle('active', this.sidebarOpen);
    },

    closeSidebar() {
        this.sidebarOpen = false;
        document.getElementById('sidebar')?.classList.remove('open');
        document.getElementById('sidebar-overlay')?.classList.remove('active');
    },

    // ============================================
    // INSTALL PROMPT
    // ============================================
    setupInstallPrompt() {
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            this.installPrompt = e;

            // Show custom prompt after delay
            setTimeout(() => {
                const prompt = document.getElementById('install-prompt');
                if (prompt && !localStorage.getItem('install-dismissed')) {
                    prompt.classList.remove('hidden');
                }
            }, 5000);
        });

        document.getElementById('install-btn')?.addEventListener('click', async () => {
            if (this.installPrompt) {
                this.installPrompt.prompt();
                const result = await this.installPrompt.userChoice;
                if (result.outcome === 'accepted') {
                    showToast('Приложение установлено!', 'success');
                }
                this.installPrompt = null;
            }
            document.getElementById('install-prompt')?.classList.add('hidden');
        });

        document.getElementById('install-dismiss')?.addEventListener('click', () => {
            document.getElementById('install-prompt')?.classList.add('hidden');
            localStorage.setItem('install-dismissed', 'true');
        });
    },

    // ============================================
    // OFFLINE DETECTION
    // ============================================
    setupOfflineDetection() {
        const updateStatus = () => {
            const banner = document.getElementById('offline-banner');
            if (!banner) return;

            if (!navigator.onLine) {
                banner.classList.remove('hidden');
                showToast('Офлайн-режим активирован', 'warning');
            } else {
                banner.classList.add('hidden');
            }
        };

        window.addEventListener('online', () => {
            updateStatus();
            showToast('Соединение восстановлено', 'success');
            this.syncData();
        });
        window.addEventListener('offline', updateStatus);
        updateStatus();
    },

    // ============================================
    // SYNC
    // ============================================
    setupSync() {
        document.getElementById('sync-btn')?.addEventListener('click', () => {
            this.syncData();
        });

        // Background sync registration
        if ('serviceWorker' in navigator && 'SyncManager' in window) {
            navigator.serviceWorker.ready.then(registration => {
                registration.sync.register('sync-orders').catch(() => {
                    // Silent fail
                });
            });
        }
    },

    async syncData() {
        const status = document.getElementById('sync-status');
        status?.classList.remove('hidden');

        try {
            await this.loadData();
            const now = new Date().toLocaleString('ru-RU');
            document.getElementById('last-sync').textContent = `Последняя синхронизация: ${now}`;
            await db.setSetting('lastSync', new Date().toISOString());
            showToast('Синхронизация завершена', 'success');
        } catch (e) {
            showToast('Ошибка синхронизации', 'error');
        } finally {
            setTimeout(() => status?.classList.add('hidden'), 1000);
        }
    },

    // ============================================
    // MODALS
    // ============================================
    setupModals() {
        // Close on overlay click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) this.closeModal(modal.id);
            });
        });

        // Close buttons
        document.querySelectorAll('.modal-close, .modal-cancel').forEach(btn => {
            btn.addEventListener('click', () => {
                const modal = btn.closest('.modal');
                if (modal) this.closeModal(modal.id);
            });
        });

        // Order form
        document.getElementById('order-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveOrder();
        });

        // Add order button
        document.getElementById('order-add-btn')?.addEventListener('click', () => {
            this.openOrderModal();
        });

        // Client search
        document.getElementById('client-search')?.addEventListener('input', (e) => {
            this.filterClients(e.target.value);
        });

        // Order filter
        document.getElementById('order-status-filter')?.addEventListener('change', (e) => {
            this.renderOrders(e.target.value);
        });

        // Tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const tabGroup = btn.closest('.pricelist-tabs, .ref-tabs');
                const tabName = btn.dataset.tab;

                tabGroup.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                const contentContainer = tabGroup.nextElementSibling?.parentElement || tabGroup.parentElement;
                contentContainer.querySelectorAll('.tab-content').forEach(c => {
                    c.classList.toggle('active', c.id === `tab-${tabName}`);
                });
            });
        });
    },

    openModal(id) {
        document.getElementById(id)?.classList.add('active');
        document.body.style.overflow = 'hidden';
    },

    closeModal(id) {
        document.getElementById(id)?.classList.remove('active');
        document.body.style.overflow = '';
    },

    // ============================================
    // ORDERS
    // ============================================
    renderOrders(filter = 'all') {
        const container = document.getElementById('orders-list');
        if (!container) return;

        let orders = this.orders;
        if (filter !== 'all') {
            orders = orders.filter(o => o.status === filter);
        }

        if (orders.length === 0) {
            container.innerHTML = '<p class="empty-state">Нет заявок</p>';
            return;
        }

        const statusLabels = {
            new: 'Новая',
            processing: 'В обработке',
            production: 'В производстве',
            ready: 'Готова к отгрузке',
            delivered: 'Доставлена',
            cancelled: 'Отменена'
        };

        container.innerHTML = orders.map(order => `
            <div class="order-card" data-id="${order.id}">
                <div class="order-card-header">
                    <div>
                        <div class="order-card-title">${order.clientName || 'Без имени'}</div>
                        <div class="order-card-meta">
                            <span>${order.address || '—'}</span>
                            <span>ТИП ${order.type}</span>
                            <span>${order.quantity} шт.</span>
                        </div>
                    </div>
                    <span class="recent-item-status status-${order.status}">${statusLabels[order.status] || order.status}</span>
                </div>
                <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 8px;">
                    ${order.note || ''}
                </div>
            </div>
        `).join('');

        container.querySelectorAll('.order-card').forEach(card => {
            card.addEventListener('click', () => {
                const id = card.dataset.id;
                this.openOrderModal(id);
            });
        });
    },

    openOrderModal(orderId = null) {
        const modal = document.getElementById('order-modal');
        const title = document.getElementById('modal-title');
        const form = document.getElementById('order-form');

        form.reset();
        document.getElementById('order-id').value = '';

        // Fill client select
        const clientSelect = document.getElementById('order-client');
        clientSelect.innerHTML = '<option value="">Выберите клиента</option>' +
            this.clients.map(c => `<option value="${c.id}">${c.name}</option>`).join('');

        if (orderId) {
            const order = this.orders.find(o => o.id === orderId);
            if (order) {
                title.textContent = 'Редактирование заявки';
                document.getElementById('order-id').value = order.id;
                document.getElementById('order-client').value = order.clientId || '';
                document.getElementById('order-address').value = order.address || '';
                document.getElementById('order-type').value = order.type || '1';
                document.getElementById('order-quantity').value = order.quantity || 1;
                document.getElementById('order-width').value = order.width || 980;
                document.getElementById('order-height').value = order.height || 2000;
                document.getElementById('order-status').value = order.status || 'new';
                document.getElementById('order-note').value = order.note || '';
            }
        } else {
            title.textContent = 'Новая заявка';
        }

        this.openModal('order-modal');
    },

    async saveOrder() {
        const id = document.getElementById('order-id').value;
        const clientId = document.getElementById('order-client').value;
        const client = this.clients.find(c => c.id === clientId);

        const order = {
            id: id || 'order-' + Date.now(),
            clientId: clientId,
            clientName: client?.name || 'Неизвестный клиент',
            address: document.getElementById('order-address').value,
            type: document.getElementById('order-type').value,
            quantity: parseInt(document.getElementById('order-quantity').value) || 1,
            width: parseInt(document.getElementById('order-width').value) || 980,
            height: parseInt(document.getElementById('order-height').value) || 2000,
            status: document.getElementById('order-status').value,
            note: document.getElementById('order-note').value,
            updatedAt: new Date().toISOString()
        };

        if (!id) {
            order.createdAt = new Date().toISOString();
        }

        try {
            await db.put('orders', order);
            await this.loadData();
            this.closeModal('order-modal');
            showToast(id ? 'Заявка обновлена' : 'Заявка создана', 'success');
        } catch (e) {
            showToast('Ошибка сохранения', 'error');
        }
    },

    renderRecentOrders() {
        const container = document.getElementById('recent-orders-list');
        if (!container) return;

        const recent = [...this.orders]
            .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))
            .slice(0, 5);

        if (recent.length === 0) {
            container.innerHTML = '<p class="empty-state">Нет данных</p>';
            return;
        }

        const statusLabels = {
            new: 'Новая', processing: 'В обработке', production: 'В производстве',
            ready: 'Готова', delivered: 'Доставлена', cancelled: 'Отменена'
        };

        container.innerHTML = recent.map(order => `
            <div class="recent-item">
                <div class="recent-item-info">
                    <h4>${order.clientName || '—'}</h4>
                    <p>${order.address || '—'} • ТИП ${order.type} • ${order.quantity} шт.</p>
                </div>
                <span class="recent-item-status status-${order.status}">${statusLabels[order.status]}</span>
            </div>
        `).join('');
    },

    // ============================================
    // CLIENTS
    // ============================================
    renderClients(filter = '') {
        const container = document.getElementById('clients-list');
        if (!container) return;

        let clients = this.clients;
        if (filter) {
            const q = filter.toLowerCase();
            clients = clients.filter(c => 
                c.name?.toLowerCase().includes(q) ||
                c.inn?.includes(q) ||
                c.address?.toLowerCase().includes(q)
            );
        }

        if (clients.length === 0) {
            container.innerHTML = '<p class="empty-state">Клиенты не найдены</p>';
            return;
        }

        container.innerHTML = clients.map(client => {
            const initials = client.name?.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase() || '??';
            return `
                <div class="client-card" data-id="${client.id}">
                    <div class="client-avatar">${initials}</div>
                    <div class="client-info">
                        <h4>${client.name}</h4>
                        <p>${client.address || '—'}</p>
                    </div>
                </div>
            `;
        }).join('');

        container.querySelectorAll('.client-card').forEach(card => {
            card.addEventListener('click', () => {
                this.openClientModal(card.dataset.id);
            });
        });
    },

    filterClients(query) {
        this.renderClients(query);
    },

    openClientModal(clientId) {
        const client = this.clients.find(c => c.id === clientId);
        if (!client) return;

        const modal = document.getElementById('client-modal');
        const title = document.getElementById('client-modal-title');
        const body = document.getElementById('client-modal-body');

        title.textContent = client.name;

        const fields = [
            ['ИНН', client.inn],
            ['КПП', client.kpp],
            ['ОГРН', client.ogrn],
            ['Ген. директор', client.director],
            ['Адрес', client.address],
            ['Email', client.email],
            ['Телефон', client.phone],
            ['Банк', client.bank],
            ['Р/с', client.account],
            ['БИК', client.bik],
            ['Примечание', client.notes]
        ].filter(([_, val]) => val);

        body.innerHTML = `
            <div class="ref-card" style="margin-bottom: 16px;">
                <table class="ref-table">
                    ${fields.map(([label, val]) => `
                        <tr><td style="color: var(--text-secondary); width: 40%;">${label}</td><td>${val}</td></tr>
                    `).join('')}
                </table>
            </div>
        `;

        // Setup call button
        const callBtn = document.getElementById('client-call-btn');
        if (callBtn) {
            callBtn.style.display = client.phone ? 'inline-flex' : 'none';
            callBtn.onclick = () => {
                window.location.href = `tel:${client.phone.replace(/\s/g, '')}`;
            };
        }

        this.openModal('client-modal');
    },

    // ============================================
    // PRICE LIST
    // ============================================
    renderPriceList() {
        // Doors table
        const doorsBody = document.getElementById('doors-price-body');
        if (doorsBody) {
            const descriptions = {
                1: 'Стандартная противопожарная дверь',
                2: 'Усиленная конструкция',
                3: 'Экономичный вариант',
                4: 'Базовая комплектация',
                5: 'Компактные размеры',
                6: 'Премиум комплектация',
                7: 'Премиум+ с усилением',
                8: 'Максимальная защита',
                9: 'Улучшенная стандартная',
                10: 'Улучшенная компактная',
                11: 'Улучшенная усиленная'
            };

            doorsBody.innerHTML = Object.entries(Calculator.doorPrices).map(([type, price]) => `
                <tr>
                    <td><strong>ТИП ${type}</strong></td>
                    <td>${descriptions[type] || 'Противопожарная дверь'}</td>
                    <td>${new Intl.NumberFormat('ru-RU').format(price)} ₽/м²</td>
                </tr>
            `).join('');
        }

        // Install table
        const installBody = document.getElementById('install-price-body');
        if (installBody) {
            installBody.innerHTML = installPrices.map(item => `
                <tr>
                    <td>${item.name}</td>
                    <td>${item.unit}</td>
                    <td>${new Intl.NumberFormat('ru-RU').format(item.price)} ₽</td>
                </tr>
            `).join('');
        }
    },

    // ============================================
    // BADGES
    // ============================================
    updateBadges() {
        const newOrders = this.orders.filter(o => o.status === 'new').length;
        const badge = document.getElementById('orders-badge');
        if (badge) {
            badge.textContent = newOrders;
            badge.classList.toggle('hidden', newOrders === 0);
        }
    }
};

// ============================================
// INITIALIZATION
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

// Handle visibility change for sync
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && navigator.onLine) {
        App.syncData();
    }
});
